<?php
    include './config.php';
    include './bootstrap_css.php';
    include './navbar.php';
    $location = $_POST['location'];
    $select = "SELECT * FROM mobile WHERE location='{$location}'";
    $result = mysqli_query($connection, $select);
    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_array($result)) {
            echo "
            <div class='container-fluid'>
            <div class='row'>
            <div class='col-lg-12'>
            <div class='card'>
            <img src='./images/{$row['images']}'> 
            <h2>Title: {$row['title']}</h2>
            <h2>Brand: {$row['brand']}</h2>
            <h3>Price: {$row['price']}</h3>
            <h4>Location: {$row['location']}</h4>
            <p>Description: {$row['description']}</p>
            <hr class='mt-2 mb-5'>
            </div>
            </div>
            </div>
            </div>
            ";
    }
}
    ?>