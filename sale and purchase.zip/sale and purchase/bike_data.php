<?php
include './config.php';
$title = $_POST['title'];
$model = $_POST['model'];
$price = $_POST['price'];
$location = $_POST['location'];
$desc = $_POST['desc'];
$image = $_FILES['image']['name'];
$tempname = $_FILES['image']['tmp_name'];
move_uploaded_file($tempname, './images/' . $image);
$insert = "INSERT INTO bike (title,model,price,location,description,images) VALUES ('{$title}',$model,$price,'{$location}','{$desc}','{$image}')";
mysqli_query($connection,$insert);
header("Location: http://localhost/pny_php_class4/");
?>