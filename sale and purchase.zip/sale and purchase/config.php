<?php
$connection=mysqli_connect("localhost","root","","sale");
$hostname='http://localhost/pny_php_class4/';
?>