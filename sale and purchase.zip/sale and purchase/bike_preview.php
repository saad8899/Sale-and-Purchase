<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bike Preview</title>
    <?php include'./bootstrap_css.php'?>
</head>

<body class="bg-dark">
    <?php include './navbar.php'?>
    <div class="container w-25">
        <div class="row my-2">
            <div class="col-12">
                <form action="./bike_filters.php" method="POST">
                    <label class="text-white" for="">Location</label>
                    <input class="form-control" type="text" name="location" id="" placeholder="Location...">
                    <button class="btn btn-info px-3 my-3 rounded-3">Filters</button>
                </form>
            </div>>
        </div>
    </div>
    <?php
    include './config.php';
    $select = "SELECT * FROM bike";
    $result = mysqli_query($connection, $select);
    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_array($result)) {
            echo "
            <a href='./bike_full.php?id={$row['id']}'><div class='container-fluid'>
            <div class='row'>
            <div class='col-lg-12 w-25'>
            <div class='card'>
            <img src='./images/{$row['images']}'> 
            <h2>Title: {$row['title']}</h2>
            <h2>Model: {$row['model']}</h2>
            <h3>Price: {$row['price']}</h3>
            <h4>Location: {$row['location']}</h4>
            <p>Description: {$row['description']}</p>
            </div>
            </div>
            </div>
            </div>
            </a>
            ";
    }
}
    ?>

</body>

</html>