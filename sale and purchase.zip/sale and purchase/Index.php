<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All-in-One</title>
    <?php include './bootstrap_css.php';?>
    <style>
        .p_image{
            position: relative;
        }
        .b_image{
            position: absolute;
            bottom:10px;
            right:10px;
        }
    </style>
</head>
<body class="bg-dark">
<?php include 'navbar.php';?>
<div class="container">
    <div class="row">
        <div class="col-lg-6 my-3">
            <div class="property p_image">
                <a href="./property.php"> <img class="rounded-5 " width="100%" src="https://empire-s3-production.bobvila.com/articles/wp-content/uploads/2022/05/The-Best-Property-Management-Course-Options.jpg" alt=""></a>
               <a class="btn btn-info b_image rounded-3" href="./property_preview.php">Ads Preview</a>
            </div>
        </div>
        <div class="col-lg-6 my-3">
            <div class="bike p_image">
                <a href="./bike.php"><img class="rounded-5" width="100%" height="402px" src="https://c4.wallpaperflare.com/wallpaper/237/987/642/heavy-bike-harley-davidson-harley-davidson-lights-wallpaper-preview.jpg" alt=""></a>
                <a class="btn btn-info b_image rounded-3" href="./bike_preview.php">Ads Preview</a>  
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-lg-6 my-3">
            <div class="car p_image">
                <a href="./car.php"><img class="rounded-5" width="100%" height="402px" src="https://images.pexels.com/photos/136872/pexels-photo-136872.jpeg?cs=srgb&dl=pexels-mike-bird-136872.jpg&fm=jpg" alt=""></a>
                <a class="btn btn-info b_image rounded-3" href="./car_preview.php">Ads Preview</a>
                
            </div>
        </div>
        <div class="col-lg-6 my-3">
            <div class="mobile p_image">
                <a href="./mobile.php"><img class="rounded-5" width="100%" height="402px" src="https://images.unsplash.com/photo-1616353071588-708dcff912e2?auto=format&fit=crop&q=80&w=1000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8YXBwbGUlMjBpcGhvbmV8ZW58MHx8MHx8fDA%3D" alt=""></a>
                <a class="btn btn-info b_image rounded-3" href="./mobile_preview.php">Ads Preview</a>
                
            </div>
        </div>
    </div>
</div>
    
<?php include './bootstrap_js.php';?>
</body>
</html>