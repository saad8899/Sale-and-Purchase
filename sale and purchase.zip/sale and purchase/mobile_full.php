<?php
    include './config.php';
    $id = $_GET['id'];
    $select = "SELECT * FROM mobile WHERE id='{$id}'";
    $result = mysqli_query($connection, $select);
    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_array($result)) {
            echo "
            <div class='container-fluid'>
            <div class='row'>
            <div class='col-lg-12'>
            <div class='card'>
            <img src='./images/{$row['images']}'> 
            <h2>Title: {$row['title']}</h2>
            <h2>Brand: {$row['brand']}</h2>
            <h3>Price: {$row['price']}</h3>
            <h4>Location: {$row['location']}</h4>
            <p>Description: {$row['description']}</p>
            </div>
            </div>
            </div>
            </div>
            </a>
            ";
        }
    }
    ?>