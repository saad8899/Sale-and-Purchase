-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2023 at 08:39 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sale`
--

-- --------------------------------------------------------

--
-- Table structure for table `bike`
--

CREATE TABLE `bike` (
  `id` int(2) NOT NULL,
  `title` varchar(50) NOT NULL,
  `model` int(4) NOT NULL,
  `price` int(5) NOT NULL,
  `location` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `images` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bike`
--

INSERT INTO `bike` (`id`, `title`, `model`, `price`, `location`, `description`, `images`) VALUES
(3, 'Hero Bike', 2022, 23000, 'Islamabad', 'Bike', 'fd76a0a590d8b1dc210a94ca70a8fdba.jpg'),
(4, 'Bike', 2021, 12000, 'Rwp', 'bike', 'FG7HKjbXsAYiBgC.jpg'),
(5, 'BMW', 2023, 89000, 'Islamabad', 'BMW', '4b3942d219669cfcf800be10013af183.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `bikedata`
--

CREATE TABLE `bikedata` (
  `id` int(2) NOT NULL,
  `title` varchar(50) NOT NULL,
  `model` int(4) NOT NULL,
  `price` int(5) NOT NULL,
  `location` varchar(30) NOT NULL,
  `description` varchar(500) NOT NULL,
  `images` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bikedata`
--

INSERT INTO `bikedata` (`id`, `title`, `model`, `price`, `location`, `description`, `images`) VALUES
(1, 'honda', 2022, 15000, 'Islamabad', 'honda bike', '2fbbcc77570213.5c8b354ca5e9d.jpg'),
(2, 'hero', 2021, 12000, 'Islamabad', 'hero', '307307355_497254455592949_4073367331744576096_n.jpg'),
(3, 'hero', 2021, 12000, 'Islamabad', 'hero', '20230422_145854.jpg'),
(4, 'hero', 2021, 12000, 'Islamabad', 'hero', '20230422_145854.jpg'),
(5, 'hero', 2021, 12000, 'Islamabad', 'hero bike', 'DSC_4531.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `id` int(2) NOT NULL,
  `title` varchar(50) NOT NULL,
  `model` int(4) NOT NULL,
  `price` int(5) NOT NULL,
  `location` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `images` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`id`, `title`, `model`, `price`, `location`, `description`, `images`) VALUES
(7, 'BMW', 2022, 28000, 'Islamabad', 'BMW', 'Ferrari-Purosangue-revealed-11-scaled.jpg'),
(8, 'honda', 2020, 230000, 'Islamabad', 'homda', '2fbbcc77570213.5c8b354ca5e9d.jpg'),
(9, 'BMW', 2023, 930000, 'Rwp', 'BMW', '1dd24b71-599d-4c76-bc3f-4188e135545c_p90447387_highres_the-new-bmw-ix-m60-0.jpg'),
(10, 'Havel', 2022, 880000, 'Rwp', 'Havel', '8ea42010e454e1a475ecbea4255e107d.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mobile`
--

CREATE TABLE `mobile` (
  `id` int(2) NOT NULL,
  `title` varchar(50) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `price` int(5) NOT NULL,
  `location` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `images` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mobile`
--

INSERT INTO `mobile` (`id`, `title`, `brand`, `price`, `location`, `description`, `images`) VALUES
(3, 'Iphone Mobile', 'Iphone', 12000, 'Rwp', 'mobile', 'AppleiPhone14Pro__1__01.jpeg'),
(4, 'Mobile', 'Iphone', 56000, 'Islamabad', 'mobile', 'iPhone-14-Pro-va-Pro-Max-se-tang-gia-ban.jpg'),
(5, 'Iphone ', 'Iphone', 56000, 'Islamabad', 'mobile', 'iPhone-14-Pro-Back-Purple-Hand.webp'),
(6, 'mobile', 'Iphone', 56000, 'Islamabad', 'mobile', 'iphone-15-green-hand.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `id` int(2) NOT NULL,
  `title` varchar(50) NOT NULL,
  `price` int(5) NOT NULL,
  `location` varchar(30) NOT NULL,
  `description` varchar(500) NOT NULL,
  `images` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `title`, `price`, `location`, `description`, `images`) VALUES
(2, 'Home', 230000, 'Islamabad', 'Home for sale', 'pexels-photo-106399.jpeg'),
(3, 'Home', 250000, 'Islamabad', 'home for sale', '37-377177_m.jpg'),
(4, 'Home', 450000, 'Islamabad', 'home ', 'wp4110663.webp'),
(5, 'home', 23000, 'Rwp', 'home', 'wp4110681.webp'),
(6, 'Salman Home', 23000, 'Rwp', 'Home', '37-377177_m.jpg'),
(7, 'Home', 250000, 'Islamabad', 'home for sale', 'what-factors-affect-property-value.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bike`
--
ALTER TABLE `bike`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bikedata`
--
ALTER TABLE `bikedata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobile`
--
ALTER TABLE `mobile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bike`
--
ALTER TABLE `bike`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bikedata`
--
ALTER TABLE `bikedata`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `car`
--
ALTER TABLE `car`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `mobile`
--
ALTER TABLE `mobile`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
