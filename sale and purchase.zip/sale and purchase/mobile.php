<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile</title>
    <?php include './bootstrap_css.php';?>
    <style>
        .property_image{
            position: relative;
        }
        .property{
            position: absolute;
            top:10px;
            right:10px;
        }
    </style>
</head>
<body class="bg-dark">
    <?php include 'navbar.php';?>
    <div class="property_image" style="z-index:222;">
        <img width="100%" height="910px" class="object-fit"
            src="https://images.unsplash.com/photo-1616353071588-708dcff912e2?auto=format&fit=crop&q=80&w=1000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8YXBwbGUlMjBpcGhvbmV8ZW58MHx8MHx8fDA%3D"
            alt="">
        <div class="container property w-50 shadow px-5 bg-transparent">
            <h1 class="display-1 text-center text-white">ADD MOBILE</h1>
            <div class="row">
                <div class="col-lg-12 my-3">
                        <form action="./mobile_data.php" enctype="multipart/form-data" method="POST">
                            <label class="text-white" for="">Title</label>
                            <input class="form-control" type="text" name="title" id="" placeholder="Title...">
                            <label class="text-white" for="">Brand</label>
                            <input class="form-control" type="text" name="brand" id="" placeholder="Brand...">
                            <label class="text-white" for="">Price</label>
                            <input class="form-control" type="number" name="price" id="" placeholder="Price...">
                            <label class="text-white" for="">Location</label>
                            <input class="form-control" type="text" name="location" id="" placeholder="Location...">
                            <label class="text-white" for="">Description</label>
                            <textarea class="form-control" name="desc" id="" cols="30"
                                rows="8">Description...</textarea>
                            <label class="text-white" for="">Images</label>
                            <input class="form-control" type="file" name="image" id="">
                            <button class="btn btn-dark my-3 w-100">Submit</button>
                        </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>